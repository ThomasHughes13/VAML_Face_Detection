clear all
close all

%% training

sampling=1;
[images, labels] = loadFaceImages("face_train.cdataset", sampling);

indexesFaces = find (labels == 1);
indexesNotFaces = find (labels == -1);

images= [images(indexesNotFaces,:); images(indexesFaces,:)];
labels= [labels(indexesNotFaces); labels(indexesFaces)];

modelSVM = SVMtraining(images, labels);

%% testing

[images, labels] = loadFaceImages("face_test.cdataset", sampling);

indexesFaces = find (labels == 1);
indexesNotFaces = find (labels == -1);

images= [images(indexesNotFaces,:); images(indexesFaces,:)];
labels= [labels(indexesNotFaces); labels(indexesFaces)];

for i=1:size(images,1)
    
    testnumber= images(i,:);
    
    classificationResult(i,1) = SVMTesting(testnumber,modelSVM);

end


%% Evaluation

comparison = (labels==classificationResult);

Accuracy = sum(comparison)/length(comparison)
ConfusionMatrix = confusionmat(labels,classificationResult);
ConfusionChart = confusionchart(ConfusionMatrix)
errorRate = 1-Accuracy
TruePos = round(ConfusionMatrix(2,2))
FalsePos = round(ConfusionMatrix(1,2))
TrueNeg = round(ConfusionMatrix(1,1))
FalseNeg = round(ConfusionMatrix(2,1))
Recall = TruePos / (TruePos+FalseNeg)
Precision = TruePos / (TruePos+FalsePos)
Specificity = TrueNeg / (TrueNeg+FalsePos)

[X,Y,T,AUC] = perfcurve(labels,classificationResult,1);
AUC
plot(X,Y)
xlabel('False positive rate') 
ylabel('True positive rate')
title('ROC for Classification by SVM')

figure
title('Correct Classification')
count=0;
i=1;
while (count<100)&&(i<=length(comparison))
   
    if comparison(i)
        count=count+1;
        subplot(10,10,count)
        Im = reshape(images(i,:),27,[]);
        imshow(Im)
    end
    
    i=i+1;
    
end


%We display 100 of the incorrectly classified images
figure
title('Wrong Classification')
count=0;
i=1;
while (count<100)&&(i<=length(comparison))
    
    if ~comparison(i)
        count=count+1;
        subplot(10,10,count)
        Im = reshape(images(i,:),27,[]);
        imshow(Im)
        title(num2str(classificationResult(i)))
    end
    
    i=i+1;
    
end

