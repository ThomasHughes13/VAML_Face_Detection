function dEuc = EuclideanDistance(sample1, sample2)
%Calculate Euclidean Distance between two sample images

sumdiff = 0;

for i=1:length(sample1)
    sumdiff =sumdiff +((sample1(i)-sample2(i))^2);
end

dEuc = sqrt(sumdiff);

end
