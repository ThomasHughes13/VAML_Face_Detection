function lut = lut_powerLaw(gamma)

temp = zeros(1,256);

for index = 1:256
    temp(index) = round((index.^gamma) / (255.^(gamma-1)));
end

lut = temp;
lut=uint8(lut);
end
