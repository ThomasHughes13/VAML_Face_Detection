function Lut = lut_linearStretch(m,c)
Lut = zeros(1,256);
for i = 1:length(Lut)
    if(i-1 < -c/m)
        Lut(i) = 0;
    elseif (i-1 > (255 - c)/m)
        Lut(i) = 255;
    
    else
        Lut(i) = (m *(i-1)) + c;
    end
end
Lut = uint8(Lut);

end