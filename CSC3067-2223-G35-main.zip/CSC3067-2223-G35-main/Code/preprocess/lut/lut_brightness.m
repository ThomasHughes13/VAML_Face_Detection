function Lut = lut_brightness(c)
    Lut = (0:255) + c;
    Lut = max(min(Lut, 255), 0);
    Lut = uint8(Lut);
end