function out = contrastPowerLaw(image, gamma)

lut = lut_powerLaw(gamma);
out = intlut(image, lut);
end