function out = contrastLinearStretch(img)

H = histogram(img,'BinLimits',[0 256],'BinWidth',1);
h = H.Values;
totalPixels = 0;
imgH = 255;
imgL = 0;

for index = 1:256
    if h(index) > 0
        imgL = index;
        break
    else
    end
end

for index=1:256
    totalPixels = totalPixels + h(index);
    if totalPixels == 486
        imgH = index;
        break
    else
    end
end

m = (255-0) / (imgH-imgL);
c = -m*imgL;



Lut = lut_linearStretch(m,c);
out = intlut(img,Lut);

end

