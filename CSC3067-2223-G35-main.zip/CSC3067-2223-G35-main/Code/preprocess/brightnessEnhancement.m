function enhanced = brightnessEnhancement(image, c)
Lut = lut_brightness(c);
enhanced = intlut(image,Lut);
end

