function image = loadImg(path)
%loadImg - Load an image from String path, cleans whitespace automatically.

image = imread(strtrim(path));

end