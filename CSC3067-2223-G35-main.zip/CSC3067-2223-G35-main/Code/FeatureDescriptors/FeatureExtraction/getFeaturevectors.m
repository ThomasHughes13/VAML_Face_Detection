function [trainingFeatures] = getFeaturevectors(trainingImages, i)

scale = 27;
vecSize = scale * 18;
    if i == 1
        for t=1:size(trainingImages,1)
            reshapedImage = reshape(trainingImages(t,:), scale,[]);
            trainingFeatures(t,:) =  reshape(reshapedImage,[1 vecSize]);
        end
    end
    if i == 2   % HoG
        for t=1:size(trainingImages,1)
            reshapedImage = reshape(trainingImages(t,:), scale,[]);
            trainingFeatures(t,:) = HogFeatureVector(reshapedImage);
        end
    end
    if i == 3  % Edge
        for t=1:size(trainingImages,1)
            reshapedImage = reshape(trainingImages(t,:), scale,[]);
            vector = edge_extraction(reshapedImage);
            trainingFeatures(t,:) =  reshape(vector,[1 vecSize]);

        end
    end
    if i == 4  % Gabor
        for t=1:size(trainingImages,1)
            reshapedImage = reshape(trainingImages(t,:), scale,[]);
            trainingFeatures(t,:) = gaborFeatureVector(reshapedImage);

        end
    end    
   size(trainingFeatures(t,:));
end