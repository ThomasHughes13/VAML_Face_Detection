%Edge detection is an image processing technique for finding the boundaries of objects within images. 
%It works by detecting discontinuities in brightness. 
%Edge detection is used for image segmentation and data extraction in areas such as image processing, computer vision, and machine vision.
%MatLab Definition - https://uk.mathworks.com/discovery/edge-detection.html

function edgeE = edge_extraction(im)

% Convert RGB iamge to grayscale
if size(im,3)==3
    im=rgb2gray(im);
end

edgeE = edge(im);

end

