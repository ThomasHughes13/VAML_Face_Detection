clear all
close all

%% Training
sampling=1;
[images, labels] = loadFaceImages('face_train.cdataset',sampling);

features = getFeaturevectors(images, 4);


indexesFaces = find (labels == 1);
indexesNotFaces = find (labels == -1);

features= [features(indexesNotFaces,:); features(indexesFaces,:)];
labels= [labels(indexesNotFaces); labels(indexesFaces)];

modelSVM = SVMtraining(features, labels);

%% Testing

[testimages, testlabels] = loadFaceImages('face_test.cdataset',sampling);

featuresTest = getFeaturevectors(testimages, 4); % Get features from images

indexesFaces = find (testlabels == 1);
indexesNotFaces = find (testlabels == -1);

featuresTest= [featuresTest(indexesNotFaces,:); featuresTest(indexesFaces,:)];
labelsTest= [testlabels(indexesNotFaces); testlabels(indexesFaces)];


for i=1:size(featuresTest,1)
    
    classificationResult(i,1) = SVMTesting(featuresTest(i,:), modelSVM);
    
end
%% Evaluation
comparison = (labelsTest==classificationResult);
Accuracy = sum(comparison)/length(comparison)
ConfusionMatrix = confusionmat(labelsTest,classificationResult);
ConfusionChart = confusionchart(ConfusionMatrix)
errorRate = 1-Accuracy
TruePos = round(ConfusionMatrix(2,2))
FalsePos = round(ConfusionMatrix(1,2))
TrueNeg = round(ConfusionMatrix(1,1))
FalseNeg = round(ConfusionMatrix(2,1))
Recall = TruePos / (TruePos+FalseNeg)
Precision = TruePos / (TruePos+FalsePos)
Specificity = TrueNeg / (TrueNeg+FalsePos)

[X,Y,T,AUC] = perfcurve(labelsTest,classificationResult,1);
AUC
plot(X,Y)
xlabel('False positive rate') 
ylabel('True positive rate')
title('ROC for Classification by SVM')