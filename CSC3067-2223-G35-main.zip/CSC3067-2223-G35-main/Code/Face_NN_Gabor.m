clear all
close all

%% training Stage

sampling=1;
[images, labels] = loadFaceImages('face_train.cdataset',sampling);
features = getFeaturevectors(images, 4);

labels(labels== -1) = 0;
indexesFaces = find (labels == 1);
indexesNotFaces = find (labels == 0);

features= [features(indexesNotFaces,:); features(indexesFaces,:)];
labels= [labels(indexesNotFaces); labels(indexesFaces)];

modelNN = NNtraining(features, labels);

%% testing
[images, labels] = loadFaceImages('face_test.cdataset',sampling);

featuresTest = getFeaturevectors(images, 4);

labels(labels== -1) = 0;
indexesFaces = find (labels == 1);
indexesNotFaces = find (labels == 0);

featuresTest= [featuresTest(indexesNotFaces,:); featuresTest(indexesFaces,:)];
labels= [labels(indexesNotFaces); labels(indexesFaces)];

for i=1:size(featuresTest,1)
    
    testnumber= featuresTest(i,:);
    
    classificationResult(i,1) = NNTesting(testnumber, modelNN);
    
end

%% Evaluation
comparison = (labels==classificationResult);
Accuracy = sum(comparison)/length(comparison)


ConfusionMatrix = confusionmat(labels,classificationResult);
ConfusionChart = confusionchart(ConfusionMatrix)
errorRate = 1-Accuracy
TruePos = round(ConfusionMatrix(2,2))
FalsePos = round(ConfusionMatrix(1,2))
TrueNeg = round(ConfusionMatrix(1,1))
FalseNeg = round(ConfusionMatrix(2,1))
Recall = TruePos / (TruePos+FalseNeg)
Precision = TruePos / (TruePos+FalsePos)
Specificity = TrueNeg / (TrueNeg+FalsePos)