function prediction  = KNNTesting(testImage,  modelNN,  K)
trainSamples = modelNN.neighbours;
for i=1: size(trainSamples)
    dists(i) = EuclideanDistance(testImage, trainSamples(i,:));
end
[d, index] = sort(dists);
ind_closest = index(1:K);
prediction = mode(modelNN.labels(ind_closest,:));