function newBounds = simpleNMS(boundsOut, yci)

rowsToDelete = [];

for i = 1:size(boundsOut,1)
    rowi = boundsOut(i,:);
    ycii = yci(i);
    
    for x = 1:size(boundsOut,1)
        ycix = yci(x);
        rowx = boundsOut(x,:);
        check = boundsOut(i,:) == boundsOut(x,:);
        if  all(check) 
            continue;
        end
        intersectArea = rectint(rowi,rowx);
        if intersectArea == 0
            continue
        end
        unionArea = rectint(rowi,rowi) + rectint(rowx,rowx) - intersectArea;
        if (intersectArea / unionArea) >  0.1

            if(ycix<ycii)
                rowsToDelete = [rowsToDelete, x];
            else
                rowsToDelete = [rowsToDelete, i];
            end
        

        end
        


    end

end

uniqueDeleteRows = unique(rowsToDelete,'stable');

boundsOut(uniqueDeleteRows,:) = []

newBounds = boundsOut;