function prediction = NNTesting(testImage, modelNN)
trainSamples = modelNN.neighbours;
for i=1: size(trainSamples,1)
    dists(i) = EuclideanDistance(testImage, trainSamples(i,:));
end
[closestSample, closestIndex] = min(dists);
prediction = modelNN.labels(closestIndex);
end