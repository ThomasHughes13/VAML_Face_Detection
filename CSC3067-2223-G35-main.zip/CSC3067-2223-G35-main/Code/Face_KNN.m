clear all
close all

%% training Stage
sampling=1;
[images, labels] = loadFaceImages("face_train.cdataset", sampling);

%In this scrpit we want to deal with a binary classification problem.
%Face or no face
labels(labels== -1) = 0;
indexesFaces = find (labels == 1);
indexesNotFaces = find (labels == 0);

images= [images(indexesNotFaces,:); images(indexesFaces,:)];
labels= [labels(indexesNotFaces); labels(indexesFaces)];

%Supervised training function that takes the examples and infers a model
modelNN = NNtraining(images, labels);

%% testing
[images, labels] = loadFaceImages("face_test.cdataset", sampling);

%In this scrpit we want to deal with a binary classification problem.
%Face or no face
labels(labels== -1) = 0;
indexesFaces = find (labels == 1);
indexesNotFaces = find (labels == 0);

images= [images(indexesNotFaces,:); images(indexesFaces,:)];
labels= [labels(indexesNotFaces); labels(indexesFaces)];
K=10

%For each testing image, we obtain a prediction based on our trained model
for i=1:size(images,1)
    
    testnumber= images(i,:);
    
    classificationResult(i,1) = KNNTesting(testnumber, modelNN, K);
    
end

%% Evaluation
% Finally we compared the predicted classification from our machine
% learning algorithm against the real labelling of the resting images
comparison = (labels==classificationResult);
Accuracy = sum(comparison)/length(comparison)

ConfusionMatrix = confusionmat(labels,classificationResult);
ConfusionChart = confusionchart(ConfusionMatrix)
errorRate = 1-Accuracy
TruePos = round(ConfusionMatrix(2,2))
FalsePos = round(ConfusionMatrix(1,2))
TrueNeg = round(ConfusionMatrix(1,1))
FalseNeg = round(ConfusionMatrix(2,1))
Recall = TruePos / (TruePos+FalseNeg)
Precision = TruePos / (TruePos+FalsePos)
Specificity = TrueNeg / (TrueNeg+FalsePos)
%We display 100 of the correctly classified images
figure
title('Correct Classification')
count=0;
i=1;
while (count<100)&&(i<=length(comparison))
   
    if comparison(i)
        count=count+1;
        subplot(10,10,count)
        Im = reshape(images(i,:),27,[]);
        imshow(Im)
    end
    
    i=i+1;
    
end

%We display 100 of the incorrectly classified images
figure
title('Wrong Classification')
count=0;
i=1;
while (count<100)&&(i<=length(comparison))
    
    if ~comparison(i)
        count=count+1;
        subplot(10,10,count)
        Im = reshape(images(i,:),27,[]);
        imshow(Im);
        title(num2str(classificationResult(i)))
    end
    
    i=i+1;
    
end

