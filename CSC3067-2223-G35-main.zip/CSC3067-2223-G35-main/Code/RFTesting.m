function prediction = RFTesting(testImage,bagger)

prediction = bagger.predict(testImage);
prediction = str2double(prediction);

end