clear all
close all
[validImgs, invalidImgs] = loadFaceImages("face_train.cdataset");

figure
sqSize = ceil(sqrt(length(validImgs)));
for i=1:length(validImgs)
    subplot(sqSize, sqSize, i), imshow(validImgs{i})
end

figure
for i=1:length(validImgs)
    validImgs{i} = preprocess(validImgs{i});
    subplot(sqSize, sqSize, i), imshow(validImgs{i})
end

figure
for i=1:length(validImgs)
    validImgs{i} = edge_extraction(validImgs{i});
    subplot(sqSize, sqSize, i), imshow(validImgs{i})

end

