function model = RFTraining(images,labels,nTrees)

% Train the TreeBagger (Decision Forest).
model = TreeBagger(nTrees,images,labels, 'Method', 'classification');

end