ObjectDetection ('im1.jpg','haarcascade_frontalface_alt.mat'); 
ObjectDetection ('im2.jpg','haarcascade_frontalface_alt.mat'); 
ObjectDetection ('im3.jpg','haarcascade_frontalface_alt.mat'); 
ObjectDetection ('im4.jpg','haarcascade_frontalface_alt.mat'); 
