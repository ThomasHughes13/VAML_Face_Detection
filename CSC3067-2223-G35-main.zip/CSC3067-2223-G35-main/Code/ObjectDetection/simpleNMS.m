function Objects = simpleNMS(Objects,threshold)

for i=1:(size(Objects,1)-1)
    j = i+1;
    while j <= size(Objects,1)
        interArea = rectint(Objects(i,1:4),Objects(j,1:4));
        area = (Objects(i,3)*Objects(j,4));
        result = interArea/area;
        if result > threshold
            confidencei = Objects(i,5);
            confidencei1 = Objects(j,5);
            if confidencei > confidencei1
                Objects(j,:) = [];
                j=i+1;
            else
                Objects(i,:) = [];
                j=i+1;
            end
        else
            j=j+1;
        end
    end
end

end

