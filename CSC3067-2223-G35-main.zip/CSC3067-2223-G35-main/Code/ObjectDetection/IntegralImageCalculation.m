function Iout= IntegralImageCalculation(Iin)

Iout = integralImage(Iin);
end
