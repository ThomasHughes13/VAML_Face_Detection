clear all
close all


img = imread('im1.jpg');
sampling=1;

%% training
[images, labels] = loadFaceImages('face_train.cdataset',sampling);


imageSize = size(images);


indexesFaces = find (labels == 1);
indexesNotFaces = find (labels == -1);

images= [images(indexesNotFaces,:); images(indexesFaces,:)];
features = getFeaturevectors(images, 2);
labels= [labels(indexesNotFaces); labels(indexesFaces)];

modelSVM = SVMtraining(features, labels);

%% Sliding Scale

scale = 27;
vecSize = scale * 18;
winSize = 25; % Size of box

for imNumber = 1:4
    name = strcat(strcat('im',num2str(imNumber)), '.jpg');
    f1(imNumber) = figure;
    Iin = imread(name); 
    Iin = preprocess(Iin, 100);
    subplot(2, 2, 1); imshow(Iin), title ('Initial Image'); 
    img = double(Iin);
    m = size(img, 1);
    n = size(img, 2);
    

    delta = 2;                 
    
    success = 0; failure = 0;
    positions = zeros(m-27, n-27);

    threshold = 5;             

    for x = 1:delta:(m-winSize)
        for y = 1:delta:(n-winSize)
            image = img(x:x+winSize-1, y:y+winSize-1);  
            reshapedTestImage = imresize(image, [scale 18]);  
            testNumber = reshape (reshapedTestImage,[1 vecSize]);
            testNumber =getFeaturevectors(testNumber, 2);
            classificationResult = SVMTesting(testNumber, modelSVM);

            if(classificationResult == 1)   
                success = success + 1;
                positions(x,y) = 255;          
            else
                failure = failure + 1;
            end
        end


    end

    %% Display Results

    % Non maximal suppression
    subplot(2,2,2), imshow(positions), title('Blobs'); 


    % Apply morphological opening to create clusters where detection takes place
    SE = strel('square',delta+2);
    positions = imclose(positions, SE); 
    subplot(2,2,3), imshow(positions), title ('After Processing');

    
    % Get the clusters or blobs in poistions 
    CC = bwconncomp(positions,8);

    % Get the centroid of each cluster
    S = regionprops(CC,'Centroid');
    
    img = uint8(img);
    subplot(2,2,4), imshow(img),title('Detection'), hold on; 
    
    for i = 1: CC.NumObjects
        % Discard clusters that are too small
        if( size(CC.PixelIdxList{i},1) >= threshold)
            % Get top left corner of bounding box
            coord = uint32( S(i).Centroid );
            % Get x & y coordinates
            x1 = coord(1);
            y1 = coord(2);
            x2 = x1+winSize-1;
            y2 = y1+winSize-1;
            plot([x1 x1 x2 x2  x1], [y1 y2 y2 y1 y1], '-g'); % Draw Box
        end
    end
 end
