function processed = preprocess(image, desiredBrightness)

processed = im2gray(image);
brightness = mean2(processed); % Get the average brightness of the image

% Loop through the image and incrementally enhance by +/- 10 until it is
% within 10 of the desired brightness

while (brightness+10) < desiredBrightness
    processed = brightnessEnhancement(processed, 10);
    brightness = mean2(processed);
end

while (brightness-10) > desiredBrightness
    processed = brightnessEnhancement(processed, -10);
    brightness = mean2(processed);
end   

processed = contrastPowerLaw(processed, 0.5);

end
