clear all 
close all
%defining evaluation variables
confusionmatrix = zeros(2,2);
roclabels =[];
rocresults = [];
%loading the images
[imagestrain, labelstrain] = loadFaceImages('face_train.cdataset',1);
[imagestest, labelstest] = loadFaceImages('face_test.cdataset',1);
%Combining the test and train dataset
images= [imagestrain; imagestest];
labels= [labelstrain; labelstest];
%using k-fold to generate indices for setting test data
folds=5;
overallAccuracy=0;
indices = crossvalind('Kfold',labels,folds);
for i = 1:folds
    classificationResult = [];
    % get the test indices for this value of i
    test = (indices == i);
    % get the training values by selecting the inverse of test values
    train = ~test;

    %% training
    imagesTrain = images(train,:);
    labelsTrain = labels(train,:);
    featuresTrain = getFeaturevectors(imagesTrain, 2);
    modelNN = NNtraining(featuresTrain, labelsTrain);

    %% testing
    imagesTest = images(test,:);
    labelsTest = labels(test,:);
    featuresTest = getFeaturevectors(imagesTest, 2);
    for i=1:size(featuresTest,1) 
        testnumber= featuresTest(i,:);
        classificationResult(i,1) = NNTesting(featuresTest, modelNN); 
    end
    %% evaluation
    comparison = (labelsTest==classificationResult);
    Accuracy = sum(comparison)/length(comparison);
    overallAccuracy = overallAccuracy + Accuracy;
    [m,order] = confusionmat(labelsTest,classificationResult);
    confusionmatrix = confusionmatrix + m;
    roclabels =[roclabels; labelsTest];
    rocresults = [rocresults; classificationResult];

end

%% overall evaluation (this will change each time as cross validation is random)
overallAccuracy = overallAccuracy/folds
cp = confusionchart(int16(confusionmatrix/folds), order)
errorRate = 1-overallAccuracy
TruePos = round(confusionmatrix(2,2)/folds)
FalsePos = round(confusionmatrix(1,2)/folds)
TrueNeg = round(confusionmatrix(1,1)/folds)
FalseNeg = round(confusionmatrix(2,1)/folds)
Recall = TruePos / (TruePos+FalseNeg)
Precision = TruePos / (TruePos+FalsePos)
Specificity = TrueNeg / (TrueNeg+FalsePos)
%roc curve
[X,Y,T,AUC] = perfcurve(roclabels,rocresults,1);
AUC
plot(X,Y)
xlabel('False positive rate') 
ylabel('True positive rate')
title('ROC for Classification by NN')




