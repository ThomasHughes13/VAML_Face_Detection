function model = SVMTraining(images, labels)


if max(labels)<2
    %binary classification - face or not face for our machine
    model.type='binary';
    
    labels(labels==0)=-1;

    %Initilaise and setup SVM parameters
    lambda = 1e-20;  
    C = 1000;
    kerneloption=5;
    kernel='poly';
    
    % Calculate the support vectors
    [xsup,w,w0,pos,tps,alpha] = svmclass(images,labels,C,lambda,kernel,kerneloption); 

    model.xsup = xsup;
    model.w = w;
    model.w0 = w0;

    model.param.kerneloption=kerneloption;
    model.param.kernel=kernel;
    
    
else
    % Multiclass SVM - we shouldn't need this
     model.type='multiclass';
    
    labels = labels+1;
    nbclass=max(labels);
    
    lambda = 1e-20;  
    C = 100000;
    kerneloption= 5;
    kernel='gaussian';
    
    % Calculate support vectors
    [xsup,w,b,nbsv]=svmmulticlassoneagainstall(images,labels,nbclass,C,lambda,kernel,kerneloption,1);
    
    model.xsup = xsup;
    model.w = w;
    model.b = b;
    model.nbsv = nbsv;

    model.param.kerneloption=kerneloption;
    model.param.kernel=kernel;
    
end



end